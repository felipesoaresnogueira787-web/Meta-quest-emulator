# TV Flutuante (Android nativo, Kotlin)

TV flutuante controlada com as maos de verdade, para celular dentro de um VR Box simples.

## Como gerar o APK (GitHub Actions)
1. Crie um repositorio no GitHub e suba TODO o conteudo desta pasta (inclusive a pasta .github).
2. Abra a aba **Actions** e rode o workflow **Build APK** (ou de um push na branch main).
3. Quando terminar, baixe o arquivo **TV-Flutuante-apk** em "Artifacts" e instale o app-debug.apk no celular.
   (O workflow baixa sozinho o modelo de maos do MediaPipe.)

## Como usar
- Segure o celular na horizontal. A camera de tras rastreia as maos.
- Pinca (polegar + indicador) em cima da TV para agarrar e mover. Solte abrindo os dedos.
- Pinca com as duas maos: estica ou encolhe a TV.
- Botoes: Video (escolher filme), VR 2 telas, Fundo (camera), Recentrar.
- No modo VR os botoes somem; toque na tela para mostrar/esconder.

## Para melhorar o reconhecimento
- Boa luz, fundo sem bagunca, maos na altura do rosto com a palma visivel.
- Constantes ajustaveis: PINCH_ON / PINCH_OFF e HOLD_FRAMES em HandTracker.kt,
  minCutoff / beta em OneEuro.kt (suavizacao x velocidade de resposta).

## Reconhecimento de mao (versao melhorada)
- IA no GPU (cai para CPU sozinho se nao der). Botao "IA" troca na hora; o rodape mostra GPU/CPU e FPS.
- Camera em 960x720, sem alocar memoria a cada quadro.
- Pinca medida em 3D (landmarks do mundo do MediaPipe): nao confunde dedos sobrepostos e nao depende da distancia.
- Pinca filtrada, com histerese e botao de sensibilidade (normal / facil / firme).
- A TV so se move com a pinca bem fechada, entao nao "escorrega" ao soltar.
- Mao some por ate 0,25 s sem soltar a TV; o esqueleto da mao aparece desenhado para voce ver o que o app esta enxergando.
