package com.tvflutuante

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.os.SystemClock
import android.util.Log
import android.util.Size
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.framework.image.MPImage
import com.google.mediapipe.tasks.components.containers.Landmark
import com.google.mediapipe.tasks.components.containers.NormalizedLandmark
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.core.Delegate
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarker
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarkerResult
import java.nio.ByteBuffer
import java.util.concurrent.Executors
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/** Estado de uma mao, ja filtrado. Coordenadas normalizadas (0..1) da imagem da camera. */
class HandSnap(
    val present: Boolean,
    val cx: Float,          // ponto medio entre polegar e indicador
    val cy: Float,
    val pinch: Boolean,     // pinca fechada (com histerese)
    val firm: Boolean,      // pinca bem fechada: so move a TV nesse estado (evita deriva ao soltar)
    val pts: FloatArray     // 21 pontos (x,y)
) {
    companion object {
        val EMPTY = HandSnap(false, 0f, 0f, false, false, FloatArray(42))
    }
}

private const val HOLD_S = 0.25          // tempo que a mao pode sumir sem soltar a TV
private const val PINCH_ON = 0.38f       // pinca/palma (medidas 3D) para fechar
private const val PINCH_OFF = 0.62f      // para abrir (histerese)
private const val RING = 4

class HandTracker(private val context: Context) {

    @Volatile var hands: Array<HandSnap> = arrayOf(HandSnap.EMPTY, HandSnap.EMPTY)
    @Volatile var frame: Bitmap? = null
    @Volatile var frameId = 0
    @Volatile var frameAspect = 4f / 3f
    @Volatile var fps = 0
    @Volatile var status = "Iniciando..."
    @Volatile var delegateName = "-"
    @Volatile var pinchScale = 1f
    @Volatile var useGpu = true

    private val executor = Executors.newSingleThreadExecutor()
    private val builder = Executors.newSingleThreadExecutor()
    @Volatile private var landmarker: HandLandmarker? = null
    private var analysis: ImageAnalysis? = null
    private var lastTs = 0L
    private var fpsCount = 0
    private var fpsT = SystemClock.uptimeMillis()

    // buffers reaproveitados (evita criar um Bitmap a cada quadro)
    private var raw: Bitmap? = null
    private var packed: ByteBuffer? = null
    private val ring = arrayOfNulls<Bitmap>(RING)
    private var ringIdx = 0

    private class Slot {
        val fx = Array(21) { OneEuro(1.0f, 30f, 1f) }
        val fy = Array(21) { OneEuro(1.0f, 30f, 1f) }
        val fr = OneEuro(2.0f, 4f, 1f)
        val pts = FloatArray(42)
        var active = false
        var lastSeen = 0.0
        var pinch = false
        var on = 0
        var off = 0
        var snap = HandSnap.EMPTY

        fun dist(x: Float, y: Float) = hypot(pts[0] - x, pts[1] - y)

        fun clear() {
            for (f in fx) f.reset()
            for (f in fy) f.reset()
            fr.reset()
            pinch = false; on = 0; off = 0
            active = false
            snap = HandSnap.EMPTY
        }

        fun update(
            d: List<NormalizedLandmark>?, w: List<Landmark>?,
            t: Double, aspect: Float, scale: Float
        ): HandSnap {
            if (d != null && d.size >= 21) {
                active = true
                lastSeen = t
                for (i in 0 until 21) {
                    pts[i * 2] = fx[i].filter(d[i].x(), t)
                    pts[i * 2 + 1] = fy[i].filter(d[i].y(), t)
                }
                fun d2(a: Int, b: Int) =
                    hypot((pts[a * 2] - pts[b * 2]) * aspect, pts[a * 2 + 1] - pts[b * 2 + 1])
                val r2 = d2(4, 8) / max(d2(0, 9), 1e-3f)

                // medidas 3D (em metros, independentes da distancia e da rotacao da mao)
                var rw = r2
                if (w != null && w.size >= 21) {
                    fun d3(a: Int, b: Int): Float {
                        val dx = w[a].x() - w[b].x()
                        val dy = w[a].y() - w[b].y()
                        val dz = w[a].z() - w[b].z()
                        return sqrt(dx * dx + dy * dy + dz * dz)
                    }
                    rw = d3(4, 8) / max(d3(0, 9), 1e-4f)
                }
                val rf = fr.filter(rw, t)

                val onT = PINCH_ON * scale
                val offT = PINCH_OFF * scale
                if (!pinch) {
                    on = if (rf < onT && r2 < 0.75f) on + 1 else 0
                    if (on >= 2) { pinch = true; off = 0 }
                } else {
                    off = if (rf > offT || r2 > 0.95f) off + 1 else 0
                    if (off >= 2) { pinch = false; on = 0 }
                }
                snap = HandSnap(
                    true,
                    (pts[8] + pts[16]) / 2f,
                    (pts[9] + pts[17]) / 2f,
                    pinch,
                    pinch && rf < onT * 1.25f,
                    pts.copyOf()
                )
            } else if (active && t - lastSeen > HOLD_S) {
                clear()
            }
            // dentro do prazo mantem o ultimo estado (nao solta a TV por uma falha curta)
            return snap
        }
    }

    private val slots = arrayOf(Slot(), Slot())

    // ================= inicio / parada =================

    fun start(owner: LifecycleOwner, rotation: Int) {
        executor.execute {
            try {
                createLandmarker(useGpu)
            } catch (e: Throwable) {
                Log.e("HandTracker", "falha ao carregar modelo", e)
                status = "Erro no modelo: ${e.message}"
                return@execute
            }
            ContextCompat.getMainExecutor(context).execute { bind(owner, rotation) }
        }
    }

    /** Troca entre GPU e CPU em tempo de execucao. */
    fun switchDelegate() {
        useGpu = !useGpu
        builder.execute {
            try {
                val old = landmarker
                createLandmarker(useGpu)
                try { old?.close() } catch (_: Throwable) {}
            } catch (e: Throwable) {
                Log.e("HandTracker", "falha ao trocar", e)
                status = "Erro ao trocar: ${e.message}"
            }
        }
    }

    private fun options(gpu: Boolean): HandLandmarker.HandLandmarkerOptions {
        val base = BaseOptions.builder().setModelAssetPath("hand_landmarker.task")
        if (gpu) base.setDelegate(Delegate.GPU)
        return HandLandmarker.HandLandmarkerOptions.builder()
            .setBaseOptions(base.build())
            .setNumHands(2)
            .setMinHandDetectionConfidence(0.5f)
            .setMinHandPresenceConfidence(0.4f)
            .setMinTrackingConfidence(0.4f)
            .setRunningMode(RunningMode.LIVE_STREAM)
            .setResultListener { result, input -> onResult(result, input) }
            .setErrorListener { e -> Log.e("HandTracker", "erro", e) }
            .build()
    }

    private fun createLandmarker(preferGpu: Boolean) {
        var lm: HandLandmarker? = null
        var name = "CPU"
        if (preferGpu) {
            try {
                lm = HandLandmarker.createFromOptions(context, options(true))
                name = "GPU"
            } catch (e: Throwable) {
                Log.w("HandTracker", "GPU indisponivel, usando CPU", e)
            }
        }
        if (lm == null) lm = HandLandmarker.createFromOptions(context, options(false))
        for (s in slots) s.clear()
        landmarker = lm
        delegateName = name
        status = "Modelo carregado ($name)"
    }

    private fun bind(owner: LifecycleOwner, rotation: Int) {
        val future = ProcessCameraProvider.getInstance(context)
        future.addListener({
            try {
                val provider = future.get()
                val a = ImageAnalysis.Builder()
                    .setTargetResolution(Size(960, 720))
                    .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .setTargetRotation(rotation)
                    .build()
                a.setAnalyzer(executor) { image -> analyze(image) }
                provider.unbindAll()
                provider.bindToLifecycle(owner, CameraSelector.DEFAULT_BACK_CAMERA, a)
                analysis = a
                status = "Camera ativa ($delegateName)"
            } catch (e: Exception) {
                Log.e("HandTracker", "falha na camera", e)
                status = "Erro na camera: ${e.message}"
            }
        }, ContextCompat.getMainExecutor(context))
    }

    fun setRotation(rotation: Int) {
        analysis?.targetRotation = rotation
    }

    fun stop() {
        analysis?.clearAnalyzer()
        try { landmarker?.close() } catch (_: Throwable) {}
        landmarker = null
    }

    // ================= quadros =================

    private fun analyze(image: ImageProxy) {
        try {
            val lm = landmarker ?: return
            val w = image.width
            val h = image.height
            val rot = image.imageInfo.rotationDegrees
            val plane = image.planes[0]
            val buf = plane.buffer
            val rowStride = plane.rowStride

            var r = raw
            if (r == null || r.width != w || r.height != h) {
                r = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                raw = r
            }
            if (rowStride == w * 4) {
                buf.rewind()
                r.copyPixelsFromBuffer(buf)
            } else {
                var p = packed
                if (p == null || p.capacity() != w * h * 4) {
                    p = ByteBuffer.allocateDirect(w * h * 4)
                    packed = p
                }
                p.clear()
                for (y in 0 until h) {
                    buf.limit(buf.capacity())
                    buf.position(y * rowStride)
                    buf.limit(min(buf.capacity(), y * rowStride + w * 4))
                    p.put(buf)
                }
                p.rewind()
                r.copyPixelsFromBuffer(p)
            }

            // gira para a orientacao da tela, escrevendo em um bitmap do anel
            val swap = rot == 90 || rot == 270
            val dw = if (swap) h else w
            val dh = if (swap) w else h
            ringIdx = (ringIdx + 1) % RING
            var dest = ring[ringIdx]
            if (dest == null || dest.width != dw || dest.height != dh) {
                dest = Bitmap.createBitmap(dw, dh, Bitmap.Config.ARGB_8888)
                ring[ringIdx] = dest
            }
            val c = Canvas(dest)
            when (rot) {
                90 -> { c.translate(h.toFloat(), 0f); c.rotate(90f) }
                180 -> { c.translate(w.toFloat(), h.toFloat()); c.rotate(180f) }
                270 -> { c.translate(0f, w.toFloat()); c.rotate(270f) }
            }
            c.drawBitmap(r, 0f, 0f, null)

            frameAspect = dw.toFloat() / dh.toFloat()
            frame = dest
            frameId++

            var ts = SystemClock.uptimeMillis()
            if (ts <= lastTs) ts = lastTs + 1
            lastTs = ts
            lm.detectAsync(BitmapImageBuilder(dest).build(), ts)
        } catch (e: Throwable) {
            Log.e("HandTracker", "analyze", e)
        } finally {
            image.close()
        }
    }

    // ================= resultados =================

    private fun onResult(result: HandLandmarkerResult, input: MPImage) {
        val t = result.timestampMs() / 1000.0
        fpsCount++
        val tn = SystemClock.uptimeMillis()
        if (tn - fpsT >= 1000) { fps = fpsCount; fpsCount = 0; fpsT = tn }

        val aspect = input.width.toFloat() / input.height.toFloat()
        val dets = result.landmarks()
        val worlds = result.worldLandmarks()
        val idx = intArrayOf(-1, -1)

        if (dets.size == 1) {
            val wx = dets[0][0].x(); val wy = dets[0][0].y()
            var best = -1
            var bd = Float.MAX_VALUE
            for (s in 0..1) if (slots[s].active) {
                val dist = slots[s].dist(wx, wy)
                if (dist < bd) { bd = dist; best = s }
            }
            val slot = when {
                best >= 0 && bd < 0.3f -> best
                !slots[0].active -> 0
                !slots[1].active -> 1
                else -> max(best, 0)
            }
            idx[slot] = 0
        } else if (dets.size >= 2) {
            val a = dets[0][0]; val b = dets[1][0]
            if (slots[0].active && slots[1].active) {
                val straight = slots[0].dist(a.x(), a.y()) + slots[1].dist(b.x(), b.y())
                val swapped = slots[0].dist(b.x(), b.y()) + slots[1].dist(a.x(), a.y())
                if (straight <= swapped) { idx[0] = 0; idx[1] = 1 } else { idx[0] = 1; idx[1] = 0 }
            } else {
                if (a.x() <= b.x()) { idx[0] = 0; idx[1] = 1 } else { idx[0] = 1; idx[1] = 0 }
            }
        }

        val scale = pinchScale
        val out = arrayOf(HandSnap.EMPTY, HandSnap.EMPTY)
        for (s in 0..1) {
            val i = idx[s]
            out[s] = slots[s].update(
                if (i >= 0) dets[i] else null,
                if (i >= 0 && i < worlds.size) worlds[i] else null,
                t, aspect, scale
            )
        }
        hands = out
    }
}
