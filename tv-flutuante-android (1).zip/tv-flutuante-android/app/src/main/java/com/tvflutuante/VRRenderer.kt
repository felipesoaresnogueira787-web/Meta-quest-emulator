package com.tvflutuante

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import android.graphics.SurfaceTexture
import android.opengl.GLES11Ext
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.GLUtils
import android.opengl.Matrix
import android.view.Surface
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.util.concurrent.atomic.AtomicBoolean
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

private const val VS_TEX = """
uniform mat4 uMVP;
uniform mat4 uTexMat;
attribute vec4 aPos;
attribute vec2 aUV;
varying vec2 vUV;
void main() {
    gl_Position = uMVP * aPos;
    vUV = (uTexMat * vec4(aUV, 0.0, 1.0)).xy;
}
"""
private const val FS_2D = """
precision mediump float;
uniform sampler2D uTex;
varying vec2 vUV;
void main() { gl_FragColor = texture2D(uTex, vUV); }
"""
private const val FS_OES = """
#extension GL_OES_EGL_image_external : require
precision mediump float;
uniform samplerExternalOES uTex;
varying vec2 vUV;
void main() { gl_FragColor = texture2D(uTex, vUV); }
"""
private const val VS_FLAT = """
uniform mat4 uMVP;
uniform float uSize;
attribute vec4 aPos;
void main() {
    gl_Position = uMVP * aPos;
    gl_PointSize = uSize;
}
"""
private const val FS_FLAT = """
precision mediump float;
uniform vec4 uColor;
uniform float uRound;
void main() {
    if (uRound > 0.5 && length(gl_PointCoord - vec2(0.5)) > 0.5) discard;
    gl_FragColor = uColor;
}
"""

private fun compile(type: Int, src: String): Int {
    val s = GLES20.glCreateShader(type)
    GLES20.glShaderSource(s, src)
    GLES20.glCompileShader(s)
    val ok = IntArray(1)
    GLES20.glGetShaderiv(s, GLES20.GL_COMPILE_STATUS, ok, 0)
    if (ok[0] == 0) throw RuntimeException("Shader: " + GLES20.glGetShaderInfoLog(s))
    return s
}

private fun link(vs: String, fs: String): Int {
    val p = GLES20.glCreateProgram()
    GLES20.glAttachShader(p, compile(GLES20.GL_VERTEX_SHADER, vs))
    GLES20.glAttachShader(p, compile(GLES20.GL_FRAGMENT_SHADER, fs))
    GLES20.glLinkProgram(p)
    val ok = IntArray(1)
    GLES20.glGetProgramiv(p, GLES20.GL_LINK_STATUS, ok, 0)
    if (ok[0] == 0) throw RuntimeException("Link: " + GLES20.glGetProgramInfoLog(p))
    return p
}

private fun fbuf(data: FloatArray): FloatBuffer =
    ByteBuffer.allocateDirect(data.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
        .also { it.put(data); it.position(0) }

private class TexProg(vs: String, fs: String) {
    val id = link(vs, fs)
    val aPos = GLES20.glGetAttribLocation(id, "aPos")
    val aUV = GLES20.glGetAttribLocation(id, "aUV")
    val uMVP = GLES20.glGetUniformLocation(id, "uMVP")
    val uTexMat = GLES20.glGetUniformLocation(id, "uTexMat")
    val uTex = GLES20.glGetUniformLocation(id, "uTex")
}

class VRRenderer(private val tracker: HandTracker) : GLSurfaceView.Renderer {

    companion object {
        const val VT = 0.62f        // tan(metade do FOV vertical) de cada olho
        const val BG_D = 8f         // distancia do fundo (camera)
        const val CURSOR_D = 2f     // profundidade em que as maos sao desenhadas
        const val IPD = 0.064f      // distancia entre os olhos (m)
        const val TV_W = 1.6f
        const val TV_H = 0.9f
        const val GRAB_MARGIN = 0.3f
    }

    // ---- controlado pela Activity ----
    @Volatile var headView = FloatArray(16).also { Matrix.setIdentityM(it, 0) }
    @Volatile var sensorReady = false
    @Volatile var needRecenter = true
    @Volatile var vrMode = false
    @Volatile var showBackground = true
    @Volatile var videoSurface: Surface? = null
    @Volatile var videoOn = false
    @Volatile var hasVideoFrame = false
    @Volatile var videoAspect = 16f / 9f
    var onSurfaceReady: ((Surface) -> Unit)? = null

    // ---- GL ----
    private var viewW = 1
    private var viewH = 1
    private lateinit var tex2d: TexProg
    private lateinit var oes: TexProg
    private var flatProg = 0
    private var fPos = 0; private var fMVP = 0; private var fColor = 0; private var fSize = 0; private var fRound = 0
    private var bgTex = 0
    private var tvTex = 0
    private var videoTex = 0
    private var surfaceTexture: SurfaceTexture? = null
    private val frameFlag = AtomicBoolean(false)
    private val videoMat = FloatArray(16).also { Matrix.setIdentityM(it, 0) }
    private val identity = FloatArray(16).also { Matrix.setIdentityM(it, 0) }

    private val quadPos = fbuf(floatArrayOf(-.5f, -.5f, 0f, .5f, -.5f, 0f, -.5f, .5f, 0f, .5f, .5f, 0f))
    private val uvBmp = fbuf(floatArrayOf(0f, 1f, 1f, 1f, 0f, 0f, 1f, 0f))   // bitmap: origem no topo
    private val uvOes = fbuf(floatArrayOf(0f, 0f, 1f, 0f, 0f, 1f, 1f, 1f))   // video: origem embaixo
    private val handBuf = ByteBuffer.allocateDirect(21 * 3 * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
    private val curBuf = ByteBuffer.allocateDirect(3 * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()

    private var lastFrameId = -1
    private var haveBg = false
    private var bgAspect = 4f / 3f

    // matrizes temporarias
    private val projMono = FloatArray(16)
    private val projStereo = FloatArray(16)
    private val tEye = FloatArray(16)
    private val vEye = FloatArray(16)
    private val pv = FloatArray(16)
    private val pt = FloatArray(16)
    private val model = FloatArray(16)
    private val mvp = FloatArray(16)

    // ---- estado da TV e da interacao ----
    private val tvPos = floatArrayOf(0f, 2f, 0f)
    private var tvDist = 2f
    private var tvScale = 1f
    private val bR = FloatArray(3)
    private val bU = FloatArray(3)
    private val bN = FloatArray(3)
    private val cursorW = Array(2) { FloatArray(3) }
    private val grabOff = Array(2) { FloatArray(3) }
    private val grabbing = BooleanArray(2)
    private val prevPinch = BooleanArray(2)
    private val moving = BooleanArray(2)
    private val bones = intArrayOf(
        0, 1, 1, 2, 2, 3, 3, 4, 0, 5, 5, 6, 6, 7, 7, 8, 5, 9, 9, 10, 10, 11, 11, 12,
        9, 13, 13, 14, 14, 15, 15, 16, 13, 17, 17, 18, 18, 19, 19, 20, 0, 17
    )
    private val boneBuf = ByteBuffer.allocateDirect(42 * 3 * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
    private val hover = BooleanArray(2)
    private var scaling = false
    private var sd0 = 1f
    private var ss0 = 1f
    private var sw = TV_W
    private var sh = TV_H

    // ================= ciclo de vida GL =================

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        GLES20.glClearColor(0f, 0f, 0f, 1f)
        GLES20.glDisable(GLES20.GL_DEPTH_TEST)
        GLES20.glEnable(GLES20.GL_BLEND)
        GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA, GLES20.GL_ONE_MINUS_SRC_ALPHA)

        tex2d = TexProg(VS_TEX, FS_2D)
        oes = TexProg(VS_TEX, FS_OES)
        flatProg = link(VS_FLAT, FS_FLAT)
        fPos = GLES20.glGetAttribLocation(flatProg, "aPos")
        fMVP = GLES20.glGetUniformLocation(flatProg, "uMVP")
        fColor = GLES20.glGetUniformLocation(flatProg, "uColor")
        fSize = GLES20.glGetUniformLocation(flatProg, "uSize")
        fRound = GLES20.glGetUniformLocation(flatProg, "uRound")

        bgTex = newTex(GLES20.GL_TEXTURE_2D)
        haveBg = false
        lastFrameId = -1

        tvTex = newTex(GLES20.GL_TEXTURE_2D)
        val test = makeTestBitmap()
        GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, test, 0)
        test.recycle()

        videoTex = newTex(GLES11Ext.GL_TEXTURE_EXTERNAL_OES)
        surfaceTexture?.release()
        val st = SurfaceTexture(videoTex)
        st.setOnFrameAvailableListener { frameFlag.set(true) }
        surfaceTexture = st
        hasVideoFrame = false
        val surf = Surface(st)
        videoSurface = surf
        onSurfaceReady?.invoke(surf)
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        viewW = width
        viewH = height
        val near = 0.05f
        val far = 50f
        fun frustum(out: FloatArray, aspect: Float) {
            val t = VT * near
            val r = t * aspect
            Matrix.frustumM(out, 0, -r, r, -t, t, near, far)
        }
        frustum(projMono, width.toFloat() / height)
        frustum(projStereo, (width / 2f) / height)
    }

    override fun onDrawFrame(gl: GL10?) {
        // video
        val st = surfaceTexture
        if (videoOn && st != null && frameFlag.getAndSet(false)) {
            st.updateTexImage()
            st.getTransformMatrix(videoMat)
            hasVideoFrame = true
        }
        // fundo (camera)
        val fb = tracker.frame
        val id = tracker.frameId
        if (fb != null && id != lastFrameId) {
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, bgTex)
            GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, fb, 0)
            lastFrameId = id
            bgAspect = fb.width.toFloat() / fb.height
            haveBg = true
        }

        val hs = tracker.hands
        val headV = headView
        update(hs, headV)

        GLES20.glViewport(0, 0, viewW, viewH)
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
        if (vrMode) {
            GLES20.glViewport(0, 0, viewW / 2, viewH)
            drawEye(-1, projStereo, headV, hs)
            GLES20.glViewport(viewW / 2, 0, viewW - viewW / 2, viewH)
            drawEye(1, projStereo, headV, hs)
        } else {
            drawEye(0, projMono, headV, hs)
        }
    }

    // ================= interacao =================

    private fun updateBasis() {
        var nx = -tvPos[0]; var ny = -tvPos[1]; var nz = -tvPos[2]
        val nl = sqrt(nx * nx + ny * ny + nz * nz).coerceAtLeast(1e-4f)
        nx /= nl; ny /= nl; nz /= nl
        var rx = -ny; var ry = nx
        val rl = sqrt(rx * rx + ry * ry)
        if (rl < 1e-4f) { rx = 1f; ry = 0f } else { rx /= rl; ry /= rl }
        val ux = ny * 0f - nz * ry
        val uy = nz * rx - nx * 0f
        val uz = nx * ry - ny * rx
        bR[0] = rx; bR[1] = ry; bR[2] = 0f
        bU[0] = ux; bU[1] = uy; bU[2] = uz
        bN[0] = nx; bN[1] = ny; bN[2] = nz
    }

    private fun recenter(v: FloatArray) {
        // direcao do olhar no mundo = -(linha 2 da matriz de visao)
        val lx = -v[2]
        val ly = -v[6]
        val h = sqrt(lx * lx + ly * ly)
        if (h > 0.2f) {
            tvPos[0] = lx / h * tvDist
            tvPos[1] = ly / h * tvDist
            tvPos[2] = 0f
        }
        tvScale = 1f
    }

    private fun update(hs: Array<HandSnap>, v: FloatArray) {
        if (needRecenter && sensorReady) {
            recenter(v)
            needRecenter = false
        }
        updateBasis()

        // tamanho da tela conforme o video
        if (videoOn && hasVideoFrame) {
            val ar = videoAspect
            if (ar > TV_W / TV_H) { sw = TV_W; sh = TV_W / ar } else { sh = TV_H; sw = TV_H * ar }
        } else { sw = TV_W; sh = TV_H }
        val s = tvScale

        val aspect = tracker.frameAspect
        val hw = VT * aspect
        val hh = VT

        // cursor de cada mao no mundo (sobre a esfera da TV)
        for (i in 0..1) {
            val h = hs[i]
            if (!h.present) { grabbing[i] = false; prevPinch[i] = false; hover[i] = false; continue }
            var ex = (h.cx - .5f) * 2f * hw
            var ey = -(h.cy - .5f) * 2f * hh
            var ez = -1f
            val l = sqrt(ex * ex + ey * ey + ez * ez)
            ex = ex / l * tvDist; ey = ey / l * tvDist; ez = ez / l * tvDist
            val c = cursorW[i]
            c[0] = v[0] * ex + v[1] * ey + v[2] * ez
            c[1] = v[4] * ex + v[5] * ey + v[6] * ez
            c[2] = v[8] * ex + v[9] * ey + v[10] * ez

            val dx = c[0] - tvPos[0]; val dy = c[1] - tvPos[1]; val dz = c[2] - tvPos[2]
            val lx = dx * bR[0] + dy * bR[1] + dz * bR[2]
            val ly = dx * bU[0] + dy * bU[1] + dz * bU[2]
            val lz = dx * bN[0] + dy * bN[1] + dz * bN[2]
            hover[i] = abs(lx) < sw * s / 2f + GRAB_MARGIN &&
                    abs(ly) < sh * s / 2f + GRAB_MARGIN && abs(lz) < 0.6f
        }

        // duas maos pinçando: esticar / encolher
        if (hs[0].present && hs[1].present && hs[0].pinch && hs[1].pinch) {
            val a = cursorW[0]; val b = cursorW[1]
            val d = sqrt((a[0] - b[0]) * (a[0] - b[0]) + (a[1] - b[1]) * (a[1] - b[1]) + (a[2] - b[2]) * (a[2] - b[2]))
            if (!scaling) { scaling = true; sd0 = max(d, 0.05f); ss0 = tvScale }
            tvScale = (ss0 * d / sd0).coerceIn(0.4f, 4f)
            grabbing[0] = false; grabbing[1] = false
            prevPinch[0] = true; prevPinch[1] = true
            return
        }
        scaling = false

        // uma mao: agarrar e mover (so comeca ao fechar a pinca perto da TV)
        for (i in 0..1) {
            val h = hs[i]
            if (!h.present) { moving[i] = false; continue }
            val c = cursorW[i]
            if (h.pinch && !prevPinch[i] && hover[i]) { grabbing[i] = true; moving[i] = false }
            if (!h.pinch) { grabbing[i] = false; moving[i] = false }
            if (grabbing[i] && h.firm) {
                if (!moving[i]) {
                    moving[i] = true
                    grabOff[i][0] = tvPos[0] - c[0]
                    grabOff[i][1] = tvPos[1] - c[1]
                    grabOff[i][2] = tvPos[2] - c[2]
                }
                val px = c[0] + grabOff[i][0]
                val py = c[1] + grabOff[i][1]
                val pz = c[2] + grabOff[i][2]
                val l = sqrt(px * px + py * py + pz * pz).coerceAtLeast(1e-3f)
                tvPos[0] = px / l * tvDist
                tvPos[1] = py / l * tvDist
                tvPos[2] = pz / l * tvDist
                updateBasis()
            } else {
                moving[i] = false
            }
            prevPinch[i] = h.pinch
        }
    }

    // ================= desenho =================

    private fun setModel(out: FloatArray, sx: Float, sy: Float, offN: Float) {
        Matrix.setIdentityM(out, 0)
        out[0] = bR[0] * sx; out[1] = bR[1] * sx; out[2] = bR[2] * sx
        out[4] = bU[0] * sy; out[5] = bU[1] * sy; out[6] = bU[2] * sy
        out[8] = bN[0]; out[9] = bN[1]; out[10] = bN[2]
        out[12] = tvPos[0] + bN[0] * offN
        out[13] = tvPos[1] + bN[1] * offN
        out[14] = tvPos[2] + bN[2] * offN
    }

    private fun drawEye(eye: Int, proj: FloatArray, headV: FloatArray, hs: Array<HandSnap>) {
        Matrix.setIdentityM(tEye, 0)
        tEye[12] = -eye * IPD / 2f
        Matrix.multiplyMM(vEye, 0, tEye, 0, headV, 0)
        Matrix.multiplyMM(pv, 0, proj, 0, vEye, 0)
        Matrix.multiplyMM(pt, 0, proj, 0, tEye, 0)

        // 1) camera ao fundo (presa a cabeca)
        if (showBackground && haveBg) {
            Matrix.setIdentityM(model, 0)
            Matrix.translateM(model, 0, 0f, 0f, -BG_D)
            Matrix.scaleM(model, 0, VT * bgAspect * BG_D * 2f, VT * BG_D * 2f, 1f)
            Matrix.multiplyMM(mvp, 0, proj, 0, model, 0)
            drawTex(tex2d, GLES20.GL_TEXTURE_2D, bgTex, mvp, identity, uvBmp)
        }

        // 2) TV: moldura + tela
        val s = tvScale
        val grabAny = grabbing[0] || grabbing[1]
        val hoverAny = hover[0] || hover[1]
        val frameColor = when {
            grabAny -> floatArrayOf(1f, 0.8f, 0.1f, 1f)
            hoverAny -> floatArrayOf(0.29f, 0.87f, 0.5f, 1f)
            else -> floatArrayOf(0.06f, 0.06f, 0.08f, 1f)
        }
        setModel(model, (sw + 0.08f) * s, (sh + 0.08f) * s, -0.01f)
        Matrix.multiplyMM(mvp, 0, pv, 0, model, 0)
        drawFlat(GLES20.GL_TRIANGLE_STRIP, quadPos, 4, mvp, frameColor, 1f, false)

        setModel(model, sw * s, sh * s, 0f)
        Matrix.multiplyMM(mvp, 0, pv, 0, model, 0)
        if (videoOn && hasVideoFrame) {
            drawTex(oes, GLES11Ext.GL_TEXTURE_EXTERNAL_OES, videoTex, mvp, videoMat, uvOes)
        } else {
            drawTex(tex2d, GLES20.GL_TEXTURE_2D, tvTex, mvp, identity, uvBmp)
        }

        // 3) maos (pontos + cursor)
        val aspect = tracker.frameAspect
        val hw = VT * aspect
        val hh = VT
        for (h in hs) {
            if (!h.present) continue
            handBuf.position(0)
            for (i in 0 until 21) {
                handBuf.put((h.pts[i * 2] - .5f) * 2f * hw * CURSOR_D)
                handBuf.put(-(h.pts[i * 2 + 1] - .5f) * 2f * hh * CURSOR_D)
                handBuf.put(-CURSOR_D)
            }
            handBuf.position(0)
            boneBuf.position(0)
            for (k in bones) {
                boneBuf.put((h.pts[k * 2] - .5f) * 2f * hw * CURSOR_D)
                boneBuf.put(-(h.pts[k * 2 + 1] - .5f) * 2f * hh * CURSOR_D)
                boneBuf.put(-CURSOR_D)
            }
            boneBuf.position(0)
            GLES20.glLineWidth(4f)
            val boneColor = if (h.pinch) floatArrayOf(1f, 0.8f, 0.1f, 0.85f) else floatArrayOf(0.3f, 0.8f, 1f, 0.8f)
            drawFlat(GLES20.GL_LINES, boneBuf, 42, pt, boneColor, 1f, false)
            val dot = if (h.pinch) floatArrayOf(1f, 0.8f, 0.1f, 1f) else floatArrayOf(1f, 1f, 1f, 0.9f)
            drawFlat(GLES20.GL_POINTS, handBuf, 21, pt, dot, 12f, true)

            curBuf.position(0)
            curBuf.put((h.cx - .5f) * 2f * hw * CURSOR_D)
            curBuf.put(-(h.cy - .5f) * 2f * hh * CURSOR_D)
            curBuf.put(-CURSOR_D)
            curBuf.position(0)
            val cc = if (h.pinch) floatArrayOf(1f, 0.8f, 0.1f, 0.85f) else floatArrayOf(0.29f, 0.87f, 0.5f, 0.6f)
            drawFlat(GLES20.GL_POINTS, curBuf, 1, pt, cc, if (h.pinch) 26f else 40f, true)
        }
    }

    private fun drawTex(p: TexProg, target: Int, tex: Int, m: FloatArray, texMat: FloatArray, uv: FloatBuffer) {
        GLES20.glUseProgram(p.id)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(target, tex)
        GLES20.glUniform1i(p.uTex, 0)
        GLES20.glUniformMatrix4fv(p.uMVP, 1, false, m, 0)
        GLES20.glUniformMatrix4fv(p.uTexMat, 1, false, texMat, 0)
        quadPos.position(0)
        uv.position(0)
        GLES20.glEnableVertexAttribArray(p.aPos)
        GLES20.glVertexAttribPointer(p.aPos, 3, GLES20.GL_FLOAT, false, 12, quadPos)
        GLES20.glEnableVertexAttribArray(p.aUV)
        GLES20.glVertexAttribPointer(p.aUV, 2, GLES20.GL_FLOAT, false, 8, uv)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
        GLES20.glDisableVertexAttribArray(p.aPos)
        GLES20.glDisableVertexAttribArray(p.aUV)
    }

    private fun drawFlat(mode: Int, buf: FloatBuffer, count: Int, m: FloatArray, color: FloatArray, size: Float, round: Boolean) {
        GLES20.glUseProgram(flatProg)
        GLES20.glUniformMatrix4fv(fMVP, 1, false, m, 0)
        GLES20.glUniform4fv(fColor, 1, color, 0)
        GLES20.glUniform1f(fSize, size)
        GLES20.glUniform1f(fRound, if (round) 1f else 0f)
        buf.position(0)
        GLES20.glEnableVertexAttribArray(fPos)
        GLES20.glVertexAttribPointer(fPos, 3, GLES20.GL_FLOAT, false, 12, buf)
        GLES20.glDrawArrays(mode, 0, count)
        GLES20.glDisableVertexAttribArray(fPos)
    }

    private fun newTex(target: Int): Int {
        val ids = IntArray(1)
        GLES20.glGenTextures(1, ids, 0)
        GLES20.glBindTexture(target, ids[0])
        GLES20.glTexParameteri(target, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(target, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(target, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexParameteri(target, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
        return ids[0]
    }

    private fun makeTestBitmap(): Bitmap {
        val b = Bitmap.createBitmap(1280, 720, Bitmap.Config.ARGB_8888)
        val c = Canvas(b)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.shader = LinearGradient(0f, 0f, 1280f, 720f, 0xFF1D4ED8.toInt(), 0xFF9333EA.toInt(), Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, 1280f, 720f, p)
        p.shader = null
        p.color = Color.WHITE
        p.textAlign = Paint.Align.CENTER
        p.textSize = 110f
        c.drawText("TV flutuante", 640f, 360f, p)
        p.textSize = 44f
        c.drawText("Toque em Video para escolher um filme", 640f, 440f, p)
        return b
    }
}
