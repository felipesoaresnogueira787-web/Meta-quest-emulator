package com.tvflutuante

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Color
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.hardware.display.DisplayManager
import android.media.MediaPlayer
import android.net.Uri
import android.opengl.GLSurfaceView
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.Surface
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat

class MainActivity : ComponentActivity(), SensorEventListener {

    private lateinit var glView: GLSurfaceView
    private lateinit var renderer: VRRenderer
    private lateinit var tracker: HandTracker
    private lateinit var bar: LinearLayout
    private lateinit var hud: TextView
    private lateinit var btnVr: Button
    private lateinit var btnBg: Button
    private lateinit var btnAi: Button
    private lateinit var btnPinch: Button
    private var pinchLevel = 0

    private lateinit var sensorManager: SensorManager
    private var rotSensor: Sensor? = null
    private var player: MediaPlayer? = null
    private var trackingStarted = false
    private val ui = Handler(Looper.getMainLooper())

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
            if (ok) startTracking()
            else Toast.makeText(this, "Sem permissao da camera nao da para rastrear as maos.", Toast.LENGTH_LONG).show()
        }

    private val videoPicker =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) playVideo(uri)
        }

    private val displayListener = object : DisplayManager.DisplayListener {
        override fun onDisplayChanged(displayId: Int) { tracker.setRotation(displayRotation()) }
        override fun onDisplayAdded(displayId: Int) {}
        override fun onDisplayRemoved(displayId: Int) {}
    }

    private val hudTick = object : Runnable {
        override fun run() {
            val n = tracker.hands.count { it.present }
            hud.text = "maos: $n   IA: ${tracker.delegateName} ${tracker.fps} fps   ${tracker.status}"
            ui.postDelayed(this, 500)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        if (Build.VERSION.SDK_INT >= 28) {
            window.attributes.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }

        tracker = HandTracker(this)
        renderer = VRRenderer(tracker)
        renderer.onSurfaceReady = { s -> runOnUiThread { player?.setSurface(s) } }

        glView = GLSurfaceView(this).apply {
            setEGLContextClientVersion(2)
            preserveEGLContextOnPause = true
            setRenderer(renderer)
            renderMode = GLSurfaceView.RENDERMODE_CONTINUOUSLY
            setOnClickListener { toggleBar() }
        }

        bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(8, 8, 8, 8)
        }
        bar.addView(makeButton("Video") { videoPicker.launch(arrayOf("video/*")) })
        btnVr = makeButton("VR 2 telas: OFF") { toggleVr() }
        bar.addView(btnVr)
        btnBg = makeButton("Fundo: ON") { toggleBg() }
        bar.addView(btnBg)
        bar.addView(makeButton("Recentrar") { renderer.needRecenter = true })
        btnAi = makeButton("IA: GPU") {
            tracker.switchDelegate()
            btnAi.text = if (tracker.useGpu) "IA: GPU" else "IA: CPU"
        }
        bar.addView(btnAi)
        btnPinch = makeButton("Pinca: normal") { cyclePinch() }
        bar.addView(btnPinch)

        hud = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 12f
            setPadding(16, 0, 0, 12)
        }

        val root = FrameLayout(this)
        root.addView(glView)
        root.addView(bar, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.TOP))
        root.addView(hud, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.START))
        setContentView(root)

        WindowInsetsControllerCompat(window, root).let {
            it.hide(WindowInsetsCompat.Type.systemBars())
            it.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }

        sensorManager = getSystemService(SENSOR_SERVICE) as SensorManager
        rotSensor = sensorManager.getDefaultSensor(Sensor.TYPE_GAME_ROTATION_VECTOR)
            ?: sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
        if (rotSensor == null) {
            Toast.makeText(this, "Este celular nao tem giroscopio/sensor de rotacao.", Toast.LENGTH_LONG).show()
        }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            startTracking()
        } else {
            permLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    private fun makeButton(text: String, onClick: () -> Unit) = Button(this).apply {
        this.text = text
        textSize = 12f
        isAllCaps = false
        setOnClickListener { onClick() }
    }

    private fun startTracking() {
        if (trackingStarted) return
        trackingStarted = true
        tracker.start(this, displayRotation())
    }

    private fun toggleVr() {
        val on = !renderer.vrMode
        renderer.vrMode = on
        btnVr.text = if (on) "VR 2 telas: ON" else "VR 2 telas: OFF"
        if (on) { bar.visibility = View.GONE; hud.visibility = View.GONE }
    }

    /** Sensibilidade da pinca: normal -> facil (fecha mais cedo) -> firme (precisa apertar mais). */
    private fun cyclePinch() {
        pinchLevel = (pinchLevel + 1) % 3
        when (pinchLevel) {
            0 -> { tracker.pinchScale = 1f; btnPinch.text = "Pinca: normal" }
            1 -> { tracker.pinchScale = 1.25f; btnPinch.text = "Pinca: facil" }
            else -> { tracker.pinchScale = 0.8f; btnPinch.text = "Pinca: firme" }
        }
    }

    private fun toggleBg() {
        renderer.showBackground = !renderer.showBackground
        btnBg.text = if (renderer.showBackground) "Fundo: ON" else "Fundo: OFF"
    }

    /** Toque na tela mostra/esconde os botoes (no modo VR eles ficam escondidos). */
    private fun toggleBar() {
        val show = bar.visibility != View.VISIBLE
        bar.visibility = if (show) View.VISIBLE else View.GONE
        hud.visibility = if (show) View.VISIBLE else View.GONE
    }

    private fun playVideo(uri: Uri) {
        val s = renderer.videoSurface ?: return
        player?.release()
        renderer.videoOn = false
        renderer.hasVideoFrame = false
        try {
            val mp = MediaPlayer()
            player = mp
            mp.setDataSource(this, uri)
            mp.setSurface(s)
            mp.isLooping = true
            mp.setOnVideoSizeChangedListener { _, w, h ->
                if (w > 0 && h > 0) renderer.videoAspect = w.toFloat() / h
            }
            mp.setOnPreparedListener { it.start(); renderer.videoOn = true }
            mp.setOnErrorListener { _, _, _ -> renderer.videoOn = false; true }
            mp.prepareAsync()
        } catch (e: Exception) {
            Toast.makeText(this, "Nao consegui abrir o video: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    // ---------- sensores ----------

    @Suppress("DEPRECATION")
    private fun displayRotation(): Int =
        if (Build.VERSION.SDK_INT >= 30) display?.rotation ?: Surface.ROTATION_90
        else windowManager.defaultDisplay.rotation

    override fun onSensorChanged(e: SensorEvent) {
        val vals = if (e.values.size > 4) e.values.copyOf(4) else e.values
        val r = FloatArray(16)
        SensorManager.getRotationMatrixFromVector(r, vals)
        val out = FloatArray(16)
        when (displayRotation()) {
            Surface.ROTATION_90 ->
                SensorManager.remapCoordinateSystem(r, SensorManager.AXIS_Y, SensorManager.AXIS_MINUS_X, out)
            Surface.ROTATION_270 ->
                SensorManager.remapCoordinateSystem(r, SensorManager.AXIS_MINUS_Y, SensorManager.AXIS_X, out)
            Surface.ROTATION_180 ->
                SensorManager.remapCoordinateSystem(r, SensorManager.AXIS_MINUS_X, SensorManager.AXIS_MINUS_Y, out)
            else -> System.arraycopy(r, 0, out, 0, 16)
        }
        renderer.headView = out
        renderer.sensorReady = true
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    override fun onResume() {
        super.onResume()
        glView.onResume()
        rotSensor?.let { sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME) }
        (getSystemService(DISPLAY_SERVICE) as DisplayManager).registerDisplayListener(displayListener, null)
        player?.let { if (!it.isPlaying) it.start() }
        ui.post(hudTick)
    }

    override fun onPause() {
        super.onPause()
        ui.removeCallbacks(hudTick)
        sensorManager.unregisterListener(this)
        (getSystemService(DISPLAY_SERVICE) as DisplayManager).unregisterDisplayListener(displayListener)
        player?.let { if (it.isPlaying) it.pause() }
        glView.onPause()
    }

    override fun onDestroy() {
        super.onDestroy()
        player?.release()
        player = null
        tracker.stop()
    }
}
