package com.tvflutuante

import kotlin.math.PI
import kotlin.math.abs

/**
 * Filtro One Euro: remove a tremedeira quando a mao esta parada
 * e quase nao atrasa quando a mao se move rapido.
 */
class OneEuro(
    private val minCutoff: Float = 1.2f,
    private val beta: Float = 25f,
    private val dCutoff: Float = 1f
) {
    private var x = 0f
    private var dx = 0f
    private var t = 0.0
    private var started = false

    private fun alpha(cutoff: Float, dt: Float): Float {
        val tau = 1f / (2f * PI.toFloat() * cutoff)
        return 1f / (1f + tau / dt)
    }

    fun reset() {
        started = false
    }

    fun filter(v: Float, tSec: Double): Float {
        if (!started) {
            started = true
            x = v
            dx = 0f
            t = tSec
            return v
        }
        val dt = (tSec - t).toFloat().coerceAtLeast(1e-3f)
        val rawDx = (v - x) / dt
        dx += alpha(dCutoff, dt) * (rawDx - dx)
        val cutoff = minCutoff + beta * abs(dx)
        x += alpha(cutoff, dt) * (v - x)
        t = tSec
        return x
    }
}
